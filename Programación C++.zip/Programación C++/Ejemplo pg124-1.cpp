#include<iostream>
using namespace std;
int main ()
{
	int n1;
	for (n1=1; n1<=10; n1++)
	   {
	   if (n1 == 5) break;
	   cout << n1 << endl;
	   }
	return 0;
}
