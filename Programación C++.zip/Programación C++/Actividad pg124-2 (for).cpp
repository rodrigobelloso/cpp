#include <iostream>
using namespace std;
int main ()
{
	int x;
	for (x=26; x>=10; x=x-2)
	{
	cout<< x << endl;
	}
	return 0;
}
