#include<iostream>
using namespace std;
int main()
{	int x, y;
	cout <<"escriba un numero"<< endl;
	cin >> x;
	cout <<"escriba un numero"<< endl;
	cin >> y;
	if (x%y==0) cout <<"el primer numero es multiplo del segundo" << endl;
	else cout <<"No son multiplos" << endl;
	return 0;
}
