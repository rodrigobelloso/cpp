#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
	float n1;
	
	cout << "Introduce un numero: ";
	cin >> n1;
	cout << "Su raiz cuadrada es: " << sqrt(n1);
	return 0;
}
