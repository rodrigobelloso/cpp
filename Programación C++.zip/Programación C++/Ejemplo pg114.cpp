#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
	int n1,n2,suma;
	cout << "Escribe un numero: ";
	cin >> n1;
	cout << "Escribe otro numero: ";
	cin >> n2;
	suma=n1+n2;
	cout << "El valor de la suma de " << n1 << " y " << n2 << "es " << suma;
	return 0;
}
