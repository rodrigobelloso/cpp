#include<iostream>
using namespace std;
int main ()
{
	int n;
	cout << "Dame un numero ";
	cin >> n;
	if (n==0) 
	cout << "Es un cero"<<endl;
	else
	cout << "El numero no era un cero, oh que pena"<<endl;
	return 0;
}
