#include<iostream>
using namespace std;
int main ()
{
	int n1;
	do
	{
	 cout << "Escribe un numero positivo: ";
	 cin >> n1;
	 if (n1<=0) cout << "El numero no es positivo." << endl;
	}
	while (n1<=0);
	cout << "BIEEENNNNNNNN";
	return 0;
}
