#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
	float n1,n2,division;
	cout << "Escribe un numero: ";
	cin >> n1;
	cout << "Escribe otro numero: ";
	cin >> n2;
	division=n1/n2;
	cout << "El valor de dividir " << n1 << " entre " << n2 << " es " << division;
	return 0;
}
