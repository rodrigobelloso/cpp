#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
	float PI=3.14159265f;
	
	cout << "El seno de 30 es: " << sin ((30*PI)/180) << endl;
	cout << "El seno de 45 es: " << sin ((45*PI)/180) << endl;
	cout << "El seno de 60 es: " << sin ((60*PI)/180) << endl;
	cout << "El seno de 90 es: " << sin ((90*PI)/180);
	return 0;
}
