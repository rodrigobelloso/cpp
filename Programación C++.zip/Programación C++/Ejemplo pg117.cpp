#include<iostream>
using namespace std;
int main ()
{
	int n;
	cout << "Dame un numero";
	cin >> n;
	if (n==0) cout << "Es un cero";
	return 0;
}
