#include <iostream>
using namespace std;
int main ()
{
	cout << "La diferencia entre 102 y 37 es " << 102-37;
	return 0;
}
