#include<iostream>
using namespace std;
int main()
{	int x;
	cout <<"escriba un numero"<< endl;
	cin >> x;
	if (x%2==0) cout <<"el numero elegido es par" << endl;
	else cout <<"el numero elegido es impar" << endl;
	return 0;
}
