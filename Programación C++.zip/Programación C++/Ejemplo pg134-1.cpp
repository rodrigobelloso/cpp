#include <iostream>
using namespace std;

void subrayar()
{
	int i;
	for (i=0;i<20;i++)
	     cout << "-";
	cout << endl;
}

int main()
{
	cout << "Primer ejemplo" << endl;
	subrayar();
	
	cout << "Segundo ejemplo" << endl;
	subrayar();
	
	cout << "Tercer ejemplo" << endl;
	subrayar();
	
	return 0;
}
