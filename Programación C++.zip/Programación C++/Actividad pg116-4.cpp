#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
	float n1,n2,n3,n4,n5;
	
	cout << "Introduce el primer numero: ";
	cin >> n1;
	cout << "Introduce el segundo numero: ";
	cin >> n2;
	cout << "Introduce el tercer numero: ";
	cin >> n3;
	cout << "Introduce el cuarto numero: ";
	cin >> n4;
	cout << "Introduce el quinto numero: ";
	cin >> n5;
	cout << "La media de los cinco es: " << (n1+n2+n3+n4+n5)/5;
	return 0;
}
