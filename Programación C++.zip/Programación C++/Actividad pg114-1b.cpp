#include <iostream>
using namespace std;
int main ()
{
	cout << "El producto de 84 y -23 es " << 81*(-23);
	return 0;
}
