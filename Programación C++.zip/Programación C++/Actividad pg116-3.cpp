#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
	float n1;
	
	cout << "Introduce el numero de millas: ";
	cin >> n1;
	cout << "En kilometros son: " << n1*1.609;
	return 0;
}
