#include<iostream>
using namespace std;
int main ()
{
	int n1;
	for (n1=10; n1>=0; n1=n1-2)   cout << n1 << endl;
	return 0;
}
