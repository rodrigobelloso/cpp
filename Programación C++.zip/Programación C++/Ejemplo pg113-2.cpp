#include <iostream>
using namespace std;
int main ()
{
	cout << "5 + 1 = " << 5+1;
	return 0;
}
