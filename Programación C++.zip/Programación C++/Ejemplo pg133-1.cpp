#include <iostream>
using namespace std;

int main()
{
	int i;
	
	cout << "Primer ejemplo" << endl;
	for (i=0;i<20;i++)
	     cout << "-";
	cout << endl;
	
	cout << "Segundo ejemplo" << endl;
	for (i=0;i<20;i++)
	     cout << "-";
	cout << endl;
	
	cout << "Tercer ejemplo" << endl;
	for (i=0;i<20;i++)
	     cout << "-";
	cout << endl;
	
	return 0;
}
