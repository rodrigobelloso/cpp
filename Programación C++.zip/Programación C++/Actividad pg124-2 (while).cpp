#include <iostream>
using namespace std;
int main ()
{
	int x=26;
	while (x>=10)
	{cout<< x << endl;
	x=x-2;
	}
	return 0;
}
