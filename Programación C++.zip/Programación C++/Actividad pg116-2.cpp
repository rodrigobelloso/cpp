#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
	float n1;
	
	cout << "Introduce un numero: ";
	cin >> n1;
	cout << "Su raiz cubica es: " << pow(n1,0.33333333333);
	return 0;
}
